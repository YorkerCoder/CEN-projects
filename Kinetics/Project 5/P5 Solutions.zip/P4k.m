function [] = P4k
    clear variables
    texp = [0;0.4;1;2;3;4;5;6;8;10;15;20;25;30;35;40;45;50;60];
    Cexp = [0;329;622;812;831;785;720;650;523;418;238;136;77;44;25;14;8;5;1]*10^-5;

    %Refine C curve with an interpolating polynomial
    Cpp = spline(texp,Cexp);
    t   = linspace(0,max(texp),1000)';
    C   = ppval(Cpp,t);

    %Generate E curve
    E   = C/trapz(t,C);

    tau = trapz(t,t.*E);
    s2  = trapz(t,(t-tau).^2.*E);
    Pe = fzero(@(Pe)(s2/tau^2 - 2/Pe + 2/Pe^2*(1-exp(-Pe))),1);
    
    CAf = 1; %mol/L/min
    k   = 0.1; %L/mol/min
    
    nodes = 5;
    [R,A,B,Q] = mcolloc(nodes-2,'left','right');
    
    param.CAf   = CAf;
    param.k     = k;
    param.Pe    = Pe;
    param.Da    = k*tau;
    param.R     = R;
    param.A     = A;
    param.B     = B;
    param.Q     = Q;
    
    f           = @(C)(P4k1(C,param));
    C0          = linspace(1,0,nodes)';
    C           = fsolve(f,C0);
    z           = R;
    Cpp         = spline(z,C);
    zfine       = linspace(0,1,100);
    Cfine       = ppval(Cpp,zfine);
    
    plot(z,C,'ro',zfine,Cfine,'k-')
    XA          = 1 - C(end);
    fprintf('Conversion for AD model is %4.2f \r', XA)
end

function [F] = P4k1(C,param)
    k = param.k;
    z = param.R;
    A = param.A;
    B = param.B;

    CAf = param.CAf;
    Da  = param.Da;
    Pe  = param.Pe;

    F       = 1/Pe*B*C - A*C - Da*CAf*C.^2;
    F(1)    = 1 + 1/Pe*A(1,:)*C - C(1); 
    F(end)  = A(end,:)*C;

end