function [] = P5b
    clear variables
    t = linspace(0,4,1000);
    
    for i = 1:length(t)
        [E(i),F(i)] = RTDs(t(i));
    end
    
    %Compute first and second moment (mean res. time and variance)
    tm      = trapz(t,t.*E);
    s2      = trapz(t,(t-tm).^2.*E);
    
    k1 = 0.1; %1/min
    k2 = k1;
    k3 = k2;
    k  = [k1;k2;k3];
    
    %Now solve the MM model.
    lspan = [max(t),0];
    Cf    = [1;0;0;0];
    f     = @(l,C)(P5b1(l,C,k,Cf));
    [l,C] = ode15s(f,lspan,Cf);
    
    XA    = (Cf(1) - C(end,1))/Cf(1);
    CB    = C(end,2);
    
    fprintf('The conversion    of A for a maximum mixdedness model is %4.2f\r', XA)
    fprintf('The concentration of B for a maximum mixdedness model is %4.2f\r', CB)

end

function [D] = P5b1(l,C,k,Cf)
    nu      = [-1  1 0 0;
                0 -1 1 0;
               -1  0 0 1;];
    r       = [k(1)*C(1);k(2)*C(2);k(3)*C(1)];
    R       = nu'*r;
    [E,F]   = RTDs(l);
    if F > 0.9999
        F = 0.9999;
    end
    D       = E/(1-F)*(C - Cf) - R;
end

function [E,F] = RTDs(t)
    if t >= 0 && t < 2
        E = 0.25*t;
        F = 0.25/2*t^2;
    else
        E = 1 - 0.25*t;
        F = t - 0.25/2*t^2 - 1;
    end
end