clear variables

%Reactor data
Qf  = 16.2; %ft3/min
CAf = 0.02; %lbmol/ft3
CBf = 2.34; %lbmol/ft3

%Because B is in such excess, the reaction is roughly first order in A.
k = 0.23; %1/min

%Enter RTD Data
texp = [0;3.7;7.4;11.1;14.8;18.5;22.2;25.9;29.6;33.3;37.0;40.7;44.4;48.1;51.8];
Eexp = [0.0000;0.0005;0.0120;0.0415;0.0627;0.0604;0.0437;0.0259;0.0133;0.0061;0.0026;0.0010;0.0004;0.0001;0.0000];

%I'll refine it a bit with a spline 
t   = linspace(0,max(texp),1000)';
Epp = griddedInterpolant(texp,Eexp,'pchip');
E   = Epp(t);

%visualize E
%plot(texp, Eexp, 'ro', t, E, 'k-')

%To me, this looks like a good fit for either TIS or Axial Dispersion, but
%for the sake of a comparison to a zero-parameter model, I'll go ahead and
%use Complete Segregation and TIS.  It doesn't hurt that these are the two
%easiest (IMO), especially for a first order reaction.

%Complete segregation first as I don't have to do much work for it

%First order reaction, so CA in each packet is:
CA = CAf*exp(-k*t);
CA_CS = trapz(t,CA.*E);
XA_CS = (CAf - CA_CS)/CAf;

%For a tanks in series model, estimate number of tanks from RTD
tau = trapz(t, t.*E);
s2  = trapz(t, (t - tau).^2.*E);
n   = tau^2/s2; %roughly 8 tanks

%For a first order reaction, solve directly for conversion from
XA_TIS = 1 - 1/(1 + k*tau/n)^n;
CA_TIS = CAf*(1 - XA_TIS);

fprintf('For CS model, I get CA = %4.4f and XA = %4.4f\r', CA_CS, XA_CS)
fprintf('For TIS model, I get CA = %4.4f and XA = %4.4f\r', CA_TIS, XA_TIS)
fprintf('Seems like a pretty safe bet that this reactor will achieve about XA = 0.97\r')
