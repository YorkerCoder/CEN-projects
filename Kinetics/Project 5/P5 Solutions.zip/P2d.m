function [] = P2d
    clear variables
    t           = linspace(0,2,1000)';
    C           = t;
    index       = t >= 1;
    C(index)    = -1*t(index)+2;
    Etemp       = C/trapz(t,C);  %Area on the C curve is 1 anyway, so it doesn't matter, but technically...
    Ftemp       = cumtrapz(t,Etemp);
    Epp         = interp1(t,Etemp,'linear','pp');
    Fpp         = interp1(t,Ftemp,'spline','pp');
    E           = @(t)(ppval(Epp,t)); %1/min
    F           = @(t)(ppval(Fpp,t));

    k1          = 0.5; %L/mol/min
    k2          = 0.12; %L/mol/min
    CAf         = 1; %mol/L
    CBf         = 0;
    CCf         = 0;
    param.k     = [k1;k2];
    param.Cf    = [CAf;CBf;CCf];
    param.E     = E;
    param.F     = F;
    
    f           = @(t,C)(P2d1(t,C,param));
    lspan       = [max(t),0];
    C0          = [CAf,CBf,CCf];
    [l,C]       = ode15s(f,lspan,C0);
    CA          = C(end,1);
    CB          = C(end,2);
    CC          = C(end,3);
    XA          = (CAf - CA)/CAf;
    SB          = 2*CB/(CAf - CA);
    SC          = 3*CC/(CAf - CA);
    
    fprintf(' CA = %4.2f\r CB = %4.2f\r CC = %4.2f\r XA = %4.4f\r SB = %4.2f\r SC = %4.2f\r', CA, CB, CC, XA, SB, SC)
end

function [D] = P2d1(lambda,C,param)
    CA = C(1);
    CB = C(2);
    CC = C(3);

    E   = param.E;
    F   = param.F;
    CAf = param.Cf(1);
    CBf = param.Cf(2);
    CCf = param.Cf(3);
    k1  = param.k(1);
    k2  = param.k(2);
    r1  = k1*CA^2;
    r2  = k2*CA*CB;
    RA  = -2*r1 - r2;
    RB  =    r1 - r2;
    RC  =         r2;
    
    D = zeros(3,1);
    D(1) = E(lambda)/(1 - F(lambda))*(CA - CAf) - RA;
    D(2) = E(lambda)/(1 - F(lambda))*(CB - CBf) - RB;
    D(3) = E(lambda)/(1 - F(lambda))*(CC - CCf) - RC;

end
