function P4l
alpha0          = 0.1;
alpha           = fminsearch(@P4l1,alpha0);
[~, QBf, tau, texp, Eexp, tmod, Emod]   = P4l1(alpha);

%Plot illustration of best fit compared to experimental RTD
plot(texp, Eexp, 'ro', tmod, Emod, 'k-')

fprintf('The backmix flow is %4.2f L/min\r', QBf)



%Now that tau is known, solve reactor balance for second order reaction w/
%2 tanks in series

k   = 0.1; %L/mol/min
CAf = 1.0; %mol/L
paramSS = [k, CAf, tau, alpha];
g   = @(C)(P4l3(C,paramSS));
C   = fsolve(g,[0.5;0.5]);
XA  = (CAf - C(2))/CAf;
fprintf('The fractional conversion in this reactor is %4.2f\r', XA)


end

function [SSE, QBf, tau, texp, Eexp, tmod, Emod] = P4l1(alpha)
    texp = [0;0.4;1;2;3;4;5;6;8;10;15;20;25;30;35;40;45;50;60];
    Cexp = [0;329;622;812;831;785;720;650;523;418;238;136;77;44;25;14;8;5;1]*10^-5;
    Eexp = Cexp/trapz(texp,Cexp);

    %Refine C curve with an interpolating polynomial
    Cpp = spline(texp,Cexp);
    t   = linspace(0,max(texp),1000)';
    C   = ppval(Cpp,t);

    %Generate E curve
    E   = C/trapz(t,C);

    %Use E curve to generate F curve
    F   = cumtrapz(t,E);

    tm  = trapz(t,t.*E);

    V       = tm*10/2;
    Qf      = 10; %L/min
    Q1      = (1+alpha)*Qf;
    Q2      = (1+alpha)*Qf;
    Q3      = (1+alpha)*Qf;
    Q4      = Qf; %L/min
    QBf     = alpha*Qf;
    tau     = V/Q1;
    param   = [alpha,tau];
    f       = @(t,C)(P4l2(t,C,param));
    tspan   = [0,max(texp)];
    C20     = 0;
    C30     = 0;
    C0      = [C20;C30];
    sol     = ode15s(f,tspan,C0);
    Fmod    = deval(sol,t,2)';
    SSE     = sum((F - Fmod).^2);

    tmod    = t(2:end);
    Emod    = diff(Fmod)./diff(t);
end

function [D] = P4l2(t,C,param)
    %Using a step change for now, Cf = constant
    Cf = 1;

    %Label contents of C vector
    C2 = C(1);
    C3 = C(2);

    alpha = param(1);
    tau   = param(2);

    %balances and equations
    C1   = (alpha*C3 + Cf)/(1+alpha);
    D    = zeros(2,1);
    D(1) = 1/tau*(C1 - C2);
    D(2) = 1/tau*(C2 - C3);
end

function [F] = P4l3(C,paramSS)
    CA2 = C(1);
    CA3 = C(2);

    k       = paramSS(1);
    CAf     = paramSS(2);
    tau     = paramSS(3);
    alpha   = paramSS(4);
    
    CA1 = (alpha*CA3 + CAf)/(1+alpha);

    F = zeros(2,1);
    F(1) = CA1 - CA2 - k*CA2^2*tau;
    F(2) = CA2 - CA3 - k*CA3^2*tau;
end
