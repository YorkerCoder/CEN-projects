clear variables
texp = [0;0.4;1;2;3;4;5;6;8;10;15;20;25;30;35;40;45;50;60];
Cexp = [0;329;622;812;831;785;720;650;523;418;238;136;77;44;25;14;8;5;1]*10^-5;

%Refine C curve with an interpolating polynomial
Cpp = spline(texp,Cexp);
t   = linspace(0,max(texp),1000)';
C   = ppval(Cpp,t);

%Generate E curve
E   = C/trapz(t,C);

%check to make sure E  curve integrates to 1
if round(trapz(t,E),1) ~= 1.0
    fprintf('E curve does not integrate to 1')
end

%Use E curve to generate F curve
F   = cumtrapz(t,E);

tau = trapz(t,t.*E);
s2  = trapz(t,(t-tau).^2.*E);
n   = tau^2/s2;

n1 = floor(n);
n2 = ceil(n);

CAf = 1; %mol/L/min
k   = 0.1; %L/mol/min

%1 tank
CA1  = fzero(@(CA)(CAf - CA - k*CA^2*tau),0.5);
XA1  = (CAf - CA1)/CAf;

%2 tanks
C    = [1;0;0];
for i = 2:3
    C(i) = fzero(@(CA)(C(i-1) - CA - k*CA^2*tau/2),0.5);
end
CA2  = C(3);
XA2  = (CAf - CA2)/CAf;

fprintf('Conversion for 1 tank is %4.2f and conversion for 2 tanks is %4.2f\r', XA1, XA2)