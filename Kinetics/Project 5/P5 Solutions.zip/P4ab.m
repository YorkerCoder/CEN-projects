clear variables
texp = [0;0.4;1;2;3;4;5;6;8;10;15;20;25;30;35;40;45;50;60];
Cexp = [0;329;622;812;831;785;720;650;523;418;238;136;77;44;25;14;8;5;1]*10^-5;

%Refine C curve with an interpolating polynomial
Cpp = spline(texp,Cexp);
t   = linspace(0,max(texp),1000)';
C   = ppval(Cpp,t);

%Check whether spline approx is reasonable.
%plot(t, C, 'k-', texp, Cexp, 'ro')

%Generate E curve
E   = C/trapz(t,C);

%check to make sure E  curve integrates to 1
if round(trapz(t,E),1) ~= 1.0
    fprintf('E curve does not integrate to 1')
end

%Use E curve to generate F curve
F   = cumtrapz(t,E);

figure(1)
plot(t,E)
xlabel('time')
ylabel('E(t)')

figure(2)
plot(t,F)
xlabel('time')
ylabel('F(t)')