function [] = P5aMM
    clear variables
    t = linspace(0,4,1000);
    
    for i = 1:length(t)
        [E(i),F(i)] = RTDs(t(i));
    end
    
    %Compute first and second moment (mean res. time and variance)
    tm      = trapz(t,t.*E);
    s2      = trapz(t,(t-tm).^2.*E);
    n       = tm^2/s2;
    tau_n   = tm/n;

    %Solve for k from conversion function for a first order reaction
    k1 = fzero(@(k)(0.5 - 1/(1+k*tau_n)^6), 1); %1/min

    %now that k is known at 300K, can solve for k at higher temperature
    T1 = 300; %K
    T2 = 310; %K
    EA = 25000; %kcal/mol
    R  = 1.987; %kcal/mol/K
    k2 = k1*exp(-EA/R*(1/T2 - 1/T1));

    %Now solve the MM model.
    CAf   = 10;
    lspan = [max(t),0];
    C0    = [CAf];
    f     = @(l,C)(P5aMM1(l,C,k2,CAf));
    [l,C] = ode15s(f,lspan,C0);
    
    
    XA_TIS  = 1 - 1/(1+k2*tau_n)^6;
    XA_MM   = (CAf - C(end))/CAf;

    fprintf('The conversion at 310K for a tanks-in-series model is %4.2f\r', XA_TIS)
    fprintf('The conversion at 310K for a maximum mixdedness model is %4.2f\r', XA_MM)

end

function [D] = P5aMM1(l,C,k2,CAf)
    CA      = C;
    r       = k2*CA;
    RA      = -r;
    [E,F]   = RTDs(l);
    if F > 0.9999
        F = 0.9999
    end
    D       = E/(1-F)*(CA - CAf) - RA;
end

function [E,F] = RTDs(t)
    if t >= 0 && t < 2
        E = 0.25*t;
        F = 0.25/2*t^2;
    else
        E = 1 - 0.25*t;
        F = t - 0.25/2*t^2 - 1;
    end
end