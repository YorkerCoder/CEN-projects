function [] = P1e0

clear variables
P2DATA  = load('P2DATA');
texp    = P2DATA(:,1)*60; %seconds
Eexp    = P2DATA(:,2)/60; %1/seconds
tfine   = linspace(0,max(texp),2000);  
Epp     = spline(texp,Eexp);
Efine   = ppval(tfine,Epp);
Ffine   = cumtrapz(tfine,Efine);
Fpp     = spline(tfine,Ffine);
E       = @(t)(ppval(Epp,t));
F       = @(t)(ppval(Fpp,t));
CAf     = 0.0313; %mol/L
k       = 175; %L^2/mol^2/sec

param.k     = k;
param.CAf   = CAf;
param.E     = E;
param.F     = F;

f       = @(lambda,C)(P1e1(lambda,C,param));
lspan   = [max(texp),0];
C0      = CAf;
[lambda,C] = ode15s(f,lspan,C0);
XA      = (CAf - C(end))/CAf
end

function [D] = P1e1(lambda,C,param)
CA = C;

E   = param.E;
F   = param.F;
CAf = param.CAf;
k   = param.k;
r   = k*CA^3;
RA  = -r;

D = E(lambda)/(1 - F(lambda))*(CA - CAf) - RA;

end