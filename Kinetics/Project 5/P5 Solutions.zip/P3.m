clear variables

t = linspace(0,20,1000)';
E = -0.005*t + 0.1;

tm = trapz(t,t.*E)
s2 = trapz(t,(t-tm).^2.*E)
n  = tm^2/s2

f  = @(Pe)(s2/tm^2 - 2/Pe + 2/Pe*(1 - exp(-Pe)));
Pe = fzero(f,1)

%Out of curiousity, I'm checking to see what the theoretical RTDs for TIS and AD look like
%overlaid on a linear RTD....I'm skeptical the fit is very good.

E_TIS = (2/tm/2)^2*t.^(2-1)/factorial((2 - 1)).*exp(-2*t/tm/2);
[t_AD,E_AD]  = ADPFRRTD_0(tm,Pe);

figure(1)
plot(t_AD, E_AD, 'b.-', t, E_TIS, 'r.-', t, E, 'k-') 