clear variables
t = linspace(0,30,1000)';

segment1 = t >= 0 & t < 10;
segment2 = t >= 10 & t < 20;
segment3 = t >= 20;

E = zeros(size(t));
E(segment2) = -0.02*t(segment2) + 0.4;

%Estimate residence time from RTD; this gives tau = 13.3633 minutes
tau = trapz(t, t.*E);
s2  = trapz(t, (t - tau).^2.*E);

%Feed/reactor data
CAf = 1.0; %Conversion is independent of concentration for a first order process, so I set a basis (not generally a good idea);
%otherwise, write balances in terms of XA to cancel it, I just know the result for Concentration, so I'm taking a shortcut.
k = 0.1; %1/min

%Solving ideal PFR, dCA/dtau = RA, where RA = -k*CA;
CA_PFR = CAf*exp(-k*tau);
XA_PFR = (CAf - CA_PFR)/CAf; %Since density is constant this is fine.

%For an ideal single CSTR, solve 0 = CAf - CA - k*tau*CA;
CA_CSTR = CAf/(1 + k*tau);
XA_CSTR = (CAf - CA_CSTR)/CAf; %Since density is constant this is fine.

%For an LFR, I don't actually know the analytical solution offhand.  
%I will just solve it from the RTD directly using the segregation model and an LFR
%since micromixing doesn't matter with a first order reaction.  A shortcut,
%I know, but it is reasonable and solving the steady state material balance
%for an LFR is somewhat cumbersome.
tLFR  = linspace(0,100,1000)';
E_LFR = zeros(size(tLFR));
LFR2  = tLFR >= tau/2;
E_LFR(LFR2) = tau^2./(2*tLFR(LFR2).^3);

%I'm using segregation model, so treat fluid as separate "batch reactor"
%packets of constant volume, then solution is known for first order
%kinetics

CA_packet = CAf*exp(-k*tLFR);

%Now I can get the average exit concentration by integrating
%CA_packet(t)*E(t)dt from 0 to t = infinity.

CA_LFR = trapz(tLFR,CA_packet.*E_LFR);
XA_LFR = (CAf - CA_LFR)/CAf;

%Now I will use the complete segregation model with the real RTD to
%determine conversion.  I already calculated the packet concentration; the
%actual RTD hits zero by t = 20, so I don't need to extent the time range
%like I did with the LFR. Recalculate CA_packet for the original time span.
%There are more elegant ways to do this, but this is fine.
CA_packet   = CAf*exp(-k*t);
CA_CS       = trapz(t,CA_packet.*E);
XA_CS       = (CAf - CA_CS)/CAf;

%I wrote a separate function to solve the Maximum Mixedness case in part e,
%calling it here to get the result for a printout.
[XA_MM] = P8e;

%For a dispersion model, I'll do the same and write an external function to
%calculate it.
[XA_AD] = P8f;

%For the tanks in series model, I can get the number of tanks directly from
%the residence time and variance.
n = tau^2/s2;

%For a first order reaction, we can compute the conversion directly for TIS
%once we know the number of tanks, the rate constant, and tau.  See course
%notes or solve material balances for n tanks,

XA_TIS = 1 - 1/(1 + k*tau/n)^n;

A = ["Model";"Single PFR"; "Single CSTR"; "LFR"; "Segregation Model"; "Maximum Mixedness"; "Dispersion Model"; "Tanks-in-Series"];
B = [XA_PFR; XA_CSTR; XA_LFR; XA_CS; XA_MM; XA_AD; XA_TIS];
B = round(B,3);
B = ["Conversion";B];
[A B]