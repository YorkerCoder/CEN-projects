clear variables
tm      = 2.2441e3; %seconds
CAf     = 0.0313; %mol/L
k       = 175; %L^2/mol^2/sec
t       = linspace(0,10*tm,1000);

CA      = sqrt(1./(1/CAf^2 + 2*k*t));
E       = zeros(size(t));
index   = t >= tm/2;
E(index) = tm^2./(2*t(index).^3);
CAbar   = trapz(t,CA.*E)
XA      = (CAf - CAbar)/CAf
