clear variables
P2DATA  = load('P2DATA');
texp    = P2DATA(:,1)*60; %seconds
Eexp    = P2DATA(:,2)/60; %1/seconds
pp      = spline(texp,Eexp);
t       = linspace(0,max(texp),200); %seconds
E       = ppval(pp,t);
k       = 175; %L^2/mol^2/s
CAf     = 0.0313;
CA      = sqrt(1./(1/CAf^2 + 2*k*t));
CAbar   = trapz(t,CA.*E)
XA      = (CAf - CAbar)/CAf
