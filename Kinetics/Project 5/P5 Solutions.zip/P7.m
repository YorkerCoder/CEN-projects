clear variables
t = linspace(0,4,20)';
F = zeros(size(t));

segment1 = t >= 0 & t < 2;
segment2 = t >= 2 & t <= 4;

F(segment1) = 0.5;
F(segment2) = 1.0;

E = diff(F)./diff(t);

%By inspection, it seems like PFR has a residence time of 2 minutes, and
%the bypass and PFR each see 50% of the feed volumetric flow.  I will solve
%the material balance for a step test and see what it looks like making
%these assumptions

%Let Qp = beta*Qf; then Qb = (1 - beta)*Qf then a balance on the mixer downstream of the PFR gives:
% Ce = beta*Cp + Cf*(1 - beta), where Ce is the concentration of tracer
% after the mixer, and Cp is the concentration of tracer coming out of the
% PFR.

%For an ideal PFR, an F curve should be given by a heaviside function delayed by the residence time:
%It seems the PFR residence time is clearly 2 minutes.  Assume the tracer
%concentration is 1; it doesn't matter b/c we will normalize it out in the
%F curve.
t2  = linspace(0,4,10000)';
tau = 2.0;
Cf  = 1.0;
Cp  = Cf*(heaviside(t2 - tau));

%Now solving the mixing point balance gives Ce, the tracer concentration at
%the exit.  Presumably, beta is a variable parameter, but it looks pretty
%clear that it is 0.5 here. My first assumption was that since the bypass tracer
%shows up instantaneously, that its volume is effectively zero and so alpha
% = 1.0; however, once you plug in the Qf = 1.0 m3/min and V = 2.0 m3, this
% gives a PFR residence time of 4 minutes, which is inconsistent.  The
% spike shows up much earlier than expected suggesting a dead volume.  By
% inspection, it must be occuping 50% of the space to give a residence time
% of 2 minutes.
alpha   = 0.5;
beta    = 0.5;
Ce      = Cp*beta + Cf*(1 - beta);

%Plot against given F curve to see how it looks; since Cf = 1, Ce = F
plot(t,F,'o', t2, Ce, 'k-')

%Looks fine, so I'll go ahead and solve the material balance for a steady
%state PFR to get the reactant concentration downstream.

CAf = 2.0; %kmol/m3
k   = 1.5; %m3/kmol/min
V   = 2.0; %m3
Qf  = 1.0; %m3/min

%Given this, we can calculate the flowrate into the PFR and its residence
%time:

Qp  = beta*Qf;
Vp  = alpha*V;
tau = Vp/Qp;

%With this, we can calculate the exit concentration from the PFR. Since CAf
%= CBf, and they are consumed in equimolar quantities, CA = CB in this
%system, simplifying the material balance on A, i.e., r = k*CA^2. Then:

CAp = (1/CAf + k*tau)^(-1);

%Solving the balance on A at the mixing point gives:

CAe = CAp*beta + CAf*(1 - beta); %or (CAp + CAf)/2 since beta = 0.5;

%Conversion is then given by

XA = (CAf - CAe)/CAf; %I get 0.43

fprintf('The fractional conversion for a PFR w/ bypass and dead volume is %4.2f\r', XA)