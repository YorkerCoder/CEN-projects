function [C] = impulsesim(t)

if t >= 0 & t <= 0.005
    C = 1000*t;
elseif t > 0.005 & t <= 0.01
    C = 10 - 1000*t;
else
    C = 0;
end
end