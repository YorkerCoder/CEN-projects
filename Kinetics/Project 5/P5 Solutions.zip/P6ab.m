function [] = P6a
    par0 = [0.5,0.5];
    PAR  = fminsearch(@P6a1,par0); %I get alpha = 0.3323, beta = 0.3331. Alpha is fraction of total tank volume treated as PFR; beta is fraction of feed flow sent to PFR.
    alpha = PAR(1);
    beta  = PAR(2);
    [~, t, C, Ce, tau_p, tau_c]  = P6a1(PAR);
    plot(t, C, 'ro', t, Ce, 'k-');

    %With these results, you can get the residence times for the PFR and CSTR
    %and, if you need them, volumes and volumetric flowrates going to each
    %reactor. To get conversion, solve the steady state balances on the CSTR
    %and PFR and then use a balance on the downstream mixer to combine the exit
    %streams.

    %Feed concentration to both reactors is identical as is rate constant;
    CAf = 1.25; %mol/L
    k   = 0.10; %L/mol/min
    Qf  = 1.00; %L/min

    %For PFR, solve dCAp/dtau = RA = -k*CAp^2
    CAp = (1/CAf + k*tau_p)^(-1);

    %For CSTR, solve 0 = CAf - CAc - k*tau_c*CAc^2
    CAc = fzero(@(CA)(CAf - CA - k*tau_c*CA^2), 0.5);

    %Solve balance on mixer for exit concentration of A
    CAe = beta*CAp + (1 - beta)*CAc;

    %Now compute fractional conversion of A
    XA  = (CAf - CAe)/CAf; % I get 0.47

    fprintf('The fractional conversion of A for a PFR and CSTR in parallel is %4.2f\r', XA)
end

function [SSE, t, C, Ce, tau_p, tau_c] = P6a1(par)
    alpha = par(1);
    beta  = par(2);
    t = linspace(0,100,1000)';
    C = zeros(size(t));
    segment1 = t >= 0 & t < 10;
    segment2 = t >= 10;
    C(segment1) = 10*(1 - exp(-0.1*t(segment1)));
    C(segment2) = 5 + 10*(1 - exp(-0.1*t(segment2)));
    %plot(t,C)

    %From the concentration response alone, this looks like a CSTR in parallel
    %with a PFR.  If you wanted to, I think you could generate an F and/or E
    %curve for this and use that for data fitting, but I think we can probably
    %fit the data just using the C curve since we are working with material
    %balances instead of RTDs anyway.

    %From the limit of the C curve as t --> inf, I can infer that the tracer
    %concentration in the feed is 15 in arbitrary units.

    Cf = 15;

    %Well, I guess I need to figure out the overall residence time of the
    %system, so I'll generate an F and E curve.

    F = C/Cf;
    E = diff(F)./diff(t);
    tau = trapz(t(2:end),t(2:end).*E); %good enough.

    %I get tau = 10.0331 minutes, which I probably could have taken from the
    %time where the PFR broke through, but I wasn't sure how the flow was
    %divided, so the PFR response may show up at some value other than the mean
    %tau (I think).


    %Writing a balance on the upstream splitter for the tracer step test gives
    %Qf*Cf = Qp*Cf + Qc*Cf (all concentrations leaving splitter are equal.
    %Then let Qp = beta*Qf, so Qc = (1 - beta)*Qf.  Let Vp = alpha*V, then Vc =
    %(1 alpha)*V.  In my notation the subscript "p" means PFR, and "c" means
    %CSTR.

    %Writing a balance on the mixer downstream of the two reactors gives Qp*Cp
    %+ Qc*Cc = Qe*Ce, where "e" is exit.  Cp and Cc are the concentrations
    %leaving the PFR and CSTR respectively.  From this, you can plug in values
    %for Qp and Qc...and use an overall balance to conclude that Qe = Qf.
    %Solve this for Ce, the exit concentration of tracer, which we'll compare to
    %our experimental data. I also used my knowledge of F curves for ideal
    %CSTRs and PFRs to write expressions for the exit concentration of tracer
    %in these systems as a function of time.

    tau_p = alpha/beta*tau;
    tau_c = (1-alpha)/(1-beta)*tau;
    Cp = Cf*heaviside(t - tau_p);
    Cc = Cf*(1 - exp(-t/tau_c));
    Ce = beta*Cp + (1 - beta)*Cc;

    %Now that we've solved for the temporal response in Ce, use it to calculate
    %a SSE for this model.

    SSE = sum((C - Ce).^2);

    %I will minimize this using fminsearch.
end