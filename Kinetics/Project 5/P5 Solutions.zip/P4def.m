clear variables
texp = [0;0.4;1;2;3;4;5;6;8;10;15;20;25;30;35;40;45;50;60];
Cexp = [0;329;622;812;831;785;720;650;523;418;238;136;77;44;25;14;8;5;1]*10^-5;

%Refine C curve with an interpolating polynomial
Cpp = spline(texp,Cexp);
t   = linspace(0,max(texp),1000)';
C   = ppval(Cpp,t);

%Generate E curve
E   = C/trapz(t,C);

%Use E curve to generate F curve
F   = cumtrapz(t,E);

%Overkill but I'll convert these to functions and evaluate using integral
%or F value at a certain time.

Epp = spline(t,E);
Fpp = spline(t,F);

RTD = @(time)(ppval(Epp,time));
CDF = @(time)(ppval(Fpp,time));

%Fraction from 2 to 4 minutes:
FRACc1 = integral(RTD,2,4);
FRACc2 = CDF(4) - CDF(2);

%Fraction spending longer than 6 minutes:
FRACd1 = integral(RTD,6,max(t));
FRACd2 = 1 - CDF(6);

%Fraction spending between 0 and 3 minutes;
FRACe1 = integral(RTD,0,3);
FRACe2 = CDF(3);

fprintf('Using the RTD, fraction between 2 and 4 minutes is %4.4f and using CDF, fraction is %4.4f\n', FRACc1, FRACc2)
fprintf('Using the RTD, fraction greater  than 6 minutes is %4.4f and using CDF, fraction is %4.4f\r', FRACd1, FRACd2)
fprintf('Using the RTD, fraction between 0 and 3 minutes is %4.4f and using CDF, fraction is %4.4f\r', FRACe1, FRACe2)