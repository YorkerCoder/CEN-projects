function [] = P6c
    clear variables
    par0 = [0.3,0.5];
    PAR  = fminsearch(@P6c1,par0); %I get alpha = 0.7507, beta = 0.333. Alpha is fraction of total tank volume treated as PFR; beta is fraction of feed flow sent to bypass.
    alpha = PAR(1);
    beta  = PAR(2);
    [~, t, C, Cp, tau_p, tau_c]  = P6c1(PAR);
    plot(t, C, 'ro', t, Cp, 'k-');

    %Feed concentration to both reactors is identical as is rate constant;
    CAf = 1.25; %mol/L
    k   = 0.10; %L/mol/min
    Qf  = 1.00; %L/min

    %Try configuration with PFR first, CSTR second
    %For PFR, solve dCAp/dtau = RA = -k*CAp^2
    CAp = (1/CAf + k*tau_p)^(-1);

    %For CSTR, solve 0 = CAp - CAc - k*tau_c*CAc^2
    CAc = fzero(@(CA)(CAp - CA - k*tau_c*CA^2), 0.5);

    %Solve balance on mixer for exit concentration of A
    CAe = beta*CAp + (1 - beta)*CAc;

    %Now compute fractional conversion of A
    XA1  = (CAf - CAe)/CAf; % I get 0.61

    %Now try configuration with CSTR first, PFR second
    
    %For CSTR, solve 0 = CAf - CAc - k*tau_c*CAc^2
    CAc = fzero(@(CA)(CAf - CA - k*tau_c*CA^2), 0.5);

    %Solve balance on mixer for exit concentration of A
    CAe = beta*CAf + (1 - beta)*CAc;

    %For PFR, solve dCAp/dtau = RA = -k*CAp^2; exit conc. from CSTR
    %w/bypass is feed to PFR
    CAp = (1/CAe + k*tau_p)^(-1);
    
    %Now compute fractional conversion of A
    XA2  = (CAf - CAp)/CAf; % I get 0.6006
    
    fprintf('The fractional conversion of A for a PFR upstream of a CSTR w/bypass is %4.2f\r', XA1)
    fprintf('The fractional conversion of A for a CSTR w/bypass upstream of a PFR is %4.2f\r', XA2)
end

function [SSE, t, C, Cp, tau_p, tau_c] = P6c1(par)
    alpha = par(1);
    beta  = par(2);
    t = linspace(0,100,1000)';
    C = zeros(size(t));
    segment1 = t >= 0 & t < 10;
    segment2 = t >= 10;
    C(segment1) = 0;
    C(segment2) = 5 + 10*(1 - exp(-0.2*(t(segment2)-10)));
    %plot(t,C)

    %I had a hard time with this one, but, to me, it looks like maybe a PFR
    %that is in parallel with a series PFR - CSTR.  I tried a parallel
    %PFR/LFR, but it didn't match the data very well.  Probably the best
    %solution is a PFR in series with a CSTR that has a bypass.  Otherwise,
    %if you model as PFR in parallel with PFR --> CSTR, it is a 3 parameter
    %model.  It fits the RTD, but it violates Fogler's ethos on # of
    %parameters.  Let's try PFR -- CSTR w/bypass:
    
    %From the limit of the C curve as t --> inf, I can infer that the tracer
    %concentration in the feed is 15 in arbitrary units.

    Cf = 15;

    %Generate an F and E curve.

    F = C/Cf;
    E = diff(F)./diff(t);
    tau = trapz(t(2:end),t(2:end).*E); %good enough.

    %I get tau = 13.3701 minutes; this is different from where the PFR spike shows up at 10 minutes...so the PFR has a residence time of 10, but the system has a different avg. res time..
    
    %I'll put the PFR downstream of the CSTR w/bypass. Writing a balance on the splitter for the tracer step test gives
    %Qf*Cf = Qc*Cf + Qb*Cf (all concentrations leaving splitter are equal.
    %Then let Qb = beta*Qf, so Qc = (1 - beta)*Qf.  Let VP = alpha*V, then Vc =
    %Vc = (1 - alpha)*V.  Presently, not 100% about the volume/residence time breakdown, but I may be able to pull the PFR taus off the figure to minimize parameter estimation.
    %I am going to guess that both PFRs have tau = 10, since nothing shows
    %up downstream until 10 minutes.  This might helps me reduce variable
    %parameters, but I haven't decided how to use the information yet.
    
    %Writing a balance on the mixer downstream of CSTR Qc*Cc
    % + Qb*Cf = Qe*Ce, where "e" is exit of the CSTR w/bypass.  From there, it is just a matter of delaying it with a heaviside function 
    %We know that Qe = Qf since the streams have recombined at that point.
    %Solve this for Ce, the exit concentration of tracer, which we'll compare to
    %our experimental data. I also used my knowledge of F curves for ideal
    %CSTRs to write expressions for the exit concentration of tracer
    %in these systems as a function of time.

    tau_p  = 10;
    tau_c  = (1 - alpha)/(1-beta)*tau;
    
    %For CSTR with bypass delayed by a heaviside step:
    Cc     = Cf.*(1 - exp(-(t - tau_p)/tau_c)); %exit tracer concentration from CSTR
    
    %Calculate the exit concentration of tracer in this system.
    Ce      = beta*Cf + (1 - beta)*Cc;
    
    %The final PFR takes the combined output from the CSTR w/bypass and delays it
    Cp      = Ce.*heaviside(t - tau_p);
    
    %Now that we've solved for the temporal response in Ce, use it to calculate
    %a SSE for this model.

    SSE = sum((C - Cp).^2);

    %I will minimize this using fminsearch.
end