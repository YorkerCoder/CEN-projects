function [] = P2a
    clear variables
    t           = linspace(0,2,1000)';
    C           = t;
    index       = t >= 1;
    C(index)    = -1*t(index)+2;
    Etemp       = C/trapz(t,C);  %Area on the C curve is 1 anyway, so it doesn't matter, but technically...
    Epp         = interp1(t,Etemp,'linear','pp');
    E           = @(t)(ppval(Epp,t)); %1/min
    
    k1          = 0.5; %L/mol/min
    CAf         = 1; %mol/L
    param.k     = [k1];
    param.Cf    = [CAf];
    param.E     = E;
    
    f           = @(t,C)(P2a1(t,C,param));
    tspan       = [0,max(t)];
    C0          = [CAf,0];
    [tout,C]    = ode15s(f,tspan,C0);
    CAbar       = C(end,2);
    XA          = (CAf - CAbar)/CAf;
    fprintf(' CAbar = %4.2f\r XA = %4.4f\r', CAbar, XA)
end

function [D] = P2a1(t,C,param)
    CA      = C(1);
    
    E       = param.E;
    k1      = param.k(1);
    r1      = k1*CA^2;
    RA      = -2*r1;
        
    D       = zeros(2,1);
    D(1)    = RA;
    D(2)    = CA*E(t);
    end