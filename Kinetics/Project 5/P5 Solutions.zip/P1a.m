function [] = P1a
    clear variables
    P2DATA  = load('P2DATA');
    texp    = P2DATA(:,1)*60; %seconds
    Eexp    = P2DATA(:,2)/60; %1/seconds
    pp      = spline(texp,Eexp);
    t       = linspace(0,max(texp),200); %seconds
    E       = ppval(pp,t);
    %plot(t, E, texp, Eexp, 'ro')
    tm      = trapz(t,t.*E);
    
    CAf     = 0.0313; %mol/L
    k       = 175; %L^2/mol^2/sec
    CA      = @(tau)(sqrt(1./(1/CAf^2 + 2*k*tau)));
       
    f       = @(tau,C)(P1a1(tau,C,k));
    CAf     = 0.0313;
    CBf     = CAf;
    CCf     = 0;
    CDf     = 0;
    tauspan = [0 tm];
    C0      = [CAf;CBf;CCf;CDf];
    options = odeset('Refine',1);
    [tau,C] = ode15s(f,tauspan,C0);
    
    plot(tau,C(:,1),'ro',tau,CA(tau))
    CA(tau(end))
    XA = (CAf - CA(tau(end)))/CAf
    XA2 = (CAf - C(end,1))/CAf
    
end

function [D] = P1a1(tau,C,k)
    CA = C(1);
    CB = C(2);
    CC = C(3);
    CD = C(4);
    
    r = k*CA*CB^2;
    
    D    = zeros(4,1);
    D(1) = -r;
    D(2) = -r;
    D(3) =  r;
    D(4) =  r;
end
    
    
    