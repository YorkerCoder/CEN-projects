function [XA_AD] = P8f
    clear variables
    t = linspace(0,30,1000)';

    segment1 = t >= 0 & t < 10;
    segment2 = t >= 10 & t < 20;
    segment3 = t >= 20;

    E = zeros(size(t));
    E(segment2) = -0.02*t(segment2) + 0.4;
    
    %Estimate residence time from RTD; this gives tau = 13.3633 minutes
    tau = trapz(t, t.*E);
    %Estimate variance
    s2  = trapz(t, (t - tau).^2.*E);
    
    %Use variance and tau to estimate Peclet number
    Pe = fzero(@(Pe)(s2/tau^2 - 2/Pe + 2/Pe*(1-exp(-Pe))),10);%Feed/reactor data

    CAf = 1.0; %Conversion is independent of concentration for a first order process, so I set a basis (not generally a good idea);
    %otherwise, write balances in terms of XA to cancel it, I just know the result for Concentration, so I'm taking a shortcut.
    k = 0.1; %1/min

    nodes = 5;
    [R,A,B,Q] = mcolloc(nodes-2,'left','right');
    
    param.Pe    = Pe; %Note I am just going to solve the dimensionless balance since Uz and L aren't given.  This is better actually b/c z_bar goes from 0 to 1, which gives a true domain for orthogonal collocation.  You only need like 5 nodes for this.
    param.Da    = k*tau;
    param.R     = R;
    param.A     = A;
    param.B     = B;
    param.Q     = Q;
    
    f           = @(C)(P8f1(C,param));
    C0          = linspace(1,0,nodes)';
    C           = fsolve(f,C0);
    z           = R;
    Cpp         = spline(z,C);
    zfine       = linspace(0,1,100);
    Cfine       = ppval(Cpp,zfine);
    
    plot(z,C,'ro',zfine,Cfine,'k-')
    XA_AD       = 1 - C(end);
end

function [F] = P8f1(C,param)
    A   = param.A;
    B   = param.B;   
    Da  = param.Da;
    Pe  = param.Pe;

    F       = 1/Pe*B*C - A*C - Da*C;
    F(1)    = 1 + 1/Pe*A(1,:)*C - C(1); 
    F(end)  = A(end,:)*C;
end