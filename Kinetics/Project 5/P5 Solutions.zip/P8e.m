function [XA_MM] = P8e
    clear variables
    t = linspace(0,30,1000)';

    segment1 = t >= 0 & t < 10;
    segment2 = t >= 10 & t < 20;
    segment3 = t >= 20;

    E = zeros(size(t));
    E(segment2) = -0.02*t(segment2) + 0.4;
    
    %Estimate residence time from RTD; this gives tau = 13.3633 minutes
    tau = trapz(t, t.*E);
    
    %For the max-mixedness model, I need both E and F as functions of t.
    %Easiest, if not most elegant, way to do that is with 
    %interopolation. Probably use linear for E since it is best described as a bunch of
    %straight lines.  The F curve, however, is probably best treated with
    %splines since it is nonlinear.
    F = cumtrapz(t,E);
    
    %Create E and F as functions of time/lambda
    Epp = interp1(t,E,'linear','pp');
    Fpp = spline(t,F);
    
    El  = @(l)(ppval(Epp,l));
    Fl  = @(l)(ppval(Fpp,l));
    
    %Feed/reactor data
    CAf = 1.0; %Conversion is independent of concentration for a first order process, so I set a basis (not generally a good idea);
    %otherwise, write balances in terms of XA to cancel it, I just know the result for Concentration, so I'm taking a shortcut.
    k = 0.1; %1/min

    %Set up max mixedness with ODE solver
    param.E     = El;
    param.F     = Fl;
    param.CAf   = CAf;
    param.k     = k;
    
    lspan = [max(t) 0];
    C0    = CAf;
    f     = @(l,C)(P8e1(l,C,param));
    [~,C] = ode15s(f,lspan,C0);
    CA_MM = C(end);
    XA_MM = (CAf - CA_MM)/CAf;
    
end

function [D] = P8e1(l,C,param)
    CA  = C;
    k   = param.k;
    CAf = param.CAf;
    E   = param.E;
    F   = param.F;
    r   = k*CA;
    RA  = -r;
    if F(l) > 0.9999
        F   = 0.9999;
    else
        F   = F(l);
    end
    D   = E(l)/(1 - F)*(CA - CAf) - RA;
end