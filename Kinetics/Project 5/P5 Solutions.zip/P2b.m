function [] = P2b
    clear variables
    t           = linspace(0,2,1000)';
    C           = t;
    index       = t >= 1;
    C(index)    = -1*t(index)+2;
    Etemp       = C/trapz(t,C);  %Area on the C curve is 1 anyway, so it doesn't matter, but technically...
    Ftemp       = cumtrapz(t,Etemp);
    Epp         = interp1(t,Etemp,'linear','pp');
    Fpp         = interp1(t,Ftemp,'spline','pp');
    E           = @(t)(ppval(Epp,t)); %1/min
    F           = @(t)(ppval(Fpp,t));

        param.F     = F;

    f           = @(lambda,C)(P2b1(lambda,C,param));
    lspan       = [max(t),0];
    C0          = CAf;
    [lambda,C]  = ode15s(f,lspan,C0);
    XA          = (CAf - C(end))/CAf
end

function [D] = P2b1(lambda,C,param)
    CA = C;

    E   = param.E;
    F   = param.F;
    CAf = param.CAf;
    k   = param.k;
    r   = k*CA^2;
    RA  = -2*r;

    D = E(lambda)/(1 - F(lambda))*(CA - CAf) - RA;

end
