function [] = P5c
    clear variables
    t = linspace(0,4,1000);
    
    for i = 1:length(t)
        [E(i),F(i)] = RTDs(t(i));
    end
    
    %Compute first and second moment (mean res. time and variance)
    tm      = trapz(t,t.*E);
    s2      = trapz(t,(t-tm).^2.*E);
    
    %Calculate Peclet number
    Pe = fzero(@(Pe)(s2/tm^2 - 2/Pe + 2/Pe*(1-exp(-Pe))),1);
    
    k1 = 0.1; %1/min
    k2 = k1;
    k3 = k2;
    
    nodes = 5;
    [R,A,B,Q] = mcolloc(nodes-2,'left','right');
    
    param.Pe    = Pe;
    param.Da    = (k1 + k3)*tm;
    param.R     = R;
    param.A     = A;
    param.B     = B;
    param.Q     = Q;
    
    f           = @(C)(P5c1(C,param));
    C0          = linspace(1,0,nodes)';
    C           = fsolve(f,C0);
    z           = R;
    Cpp         = spline(z,C);
    zfine       = linspace(0,1,100);
    Cfine       = ppval(Cpp,zfine);
    
    plot(z,C,'ro',zfine,Cfine,'k-')
    XA          = 1 - C(end);
    
    fprintf('The conversion of A for an Axial Dispersion model is %4.2f\r', XA)

end

function [F] = P5c1(C,param)
    A = param.A;
    B = param.B;
   
    Da  = param.Da;
    Pe  = param.Pe;

    F       = 1/Pe*B*C - A*C - Da*C;
    F(1)    = 1 + 1/Pe*A(1,:)*C - C(1); 
    F(end)  = A(end,:)*C;

end

function [E,F] = RTDs(t)
    if t >= 0 && t < 2
        E = 0.25*t;
        F = 0.25/2*t^2;
    else
        E = 1 - 0.25*t;
        F = t - 0.25/2*t^2 - 1;
    end
end