function [tRTD,E] = ADPFRRTD_0(tau,Pe)
  nodes = 100;
  param.nodes = nodes;
  tsteps      = 1000;
  CAf         = 1;
  c0          = zeros(nodes,1);
  cp0         = zeros(nodes,1);
  tout        = zeros(tsteps,length(Pe));
  Cout        = zeros(tsteps,length(Pe));
  F           = zeros(tsteps,length(Pe));
  tRTD        = zeros(tsteps-1,length(Pe));
  E           = zeros(tsteps-1,length(Pe));
  
  for i = 1:length(Pe)
    thetamin    = 0;
    thetamax    = 5;
    thetaspan   = linspace(thetamin,thetamax,tsteps)';
    param.Pe    = Pe(i);
    f1          = @(theta,c,cp)ADPFRRTD_1(theta,c,cp,param);
    options     = odeset('AbsTol',1e-8,'RelTol',1e-8);
    %[c0,cp0]   = decic(f1,0,c0,cfix,cp0,cpfix);
    [theta,C]   = ode15i(f1,thetaspan,c0,cp0,options);
    tout(:,i)   = theta*tau;
    Cout(:,i)   = C(:,end);
    F(:,i)      = C(:,end)/CAf;
    tRTD(:,i)   = tout(2:end,i);
    E(:,i)      = diff(Cout(:,i))./diff(tout(:,i));
  end
end

function [res] = ADPFRRTD_1(t,c,cp,param)  
  Pe    = param.Pe;
  nodes = param.nodes;
  
  [R,A,B,Q] = mcolloc(nodes-2,'left','right');
  R = R*1;
  A = A/1;
  B = B/1;
  Q = Q*1;
  
  res           = cp -1/Pe*B*c + A*c;  
  res(1)        = 1 + 1/Pe*A(1,:)*c - c(1);       
  res(nodes)    = A(end,:)*c;   
end