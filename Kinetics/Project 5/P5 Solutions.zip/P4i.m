function [] = P4i
    clear variables
    texp = [0;0.4;1;2;3;4;5;6;8;10;15;20;25;30;35;40;45;50;60];
    Cexp = [0;329;622;812;831;785;720;650;523;418;238;136;77;44;25;14;8;5;1]*10^-5;

    %Refine C curve with an interpolating polynomial
    Cpp = spline(texp,Cexp);
    t   = linspace(0,max(texp),1000)';
    C   = ppval(Cpp,t);

    %Check whether spline approx is reasonable.
    %plot(t, C, 'k-', texp, Cexp, 'ro')

    %Generate E curve
    E   = C/trapz(t,C);
    
    %Use E curve to generate F curve
    F   = cumtrapz(t,E);
    
    %Generate time functions for both E and F
    Epp = spline(t,E);
    Fpp = spline(t,F);
    
    E   = @(time)(ppval(Epp,time));
    F   = @(time)(ppval(Fpp,time));
    
    %In a maximum mixedness model w/ CAf = 1 mol/L, k = 0.1 L/mol/min, r = k*CA^2
    CAf     = 1; %mol/L
    k       = 0.1; %L/mol/min
    
    
    param.E     = E;
    param.F     = F;
    param.CAf   = CAf;
    param.k     = k;
    
    f       = @(l,C)(P4i1(l,C,param));
    lspan   = [max(t) 0];
    C0      = [CAf];
    [l,C]   = ode15s(f,lspan,C0);
    CA      = C(end);
    XA      = (CAf - CA)/CAf
end

function [D] = P4i1(l,C,param)
    CA = C(1);

    E   = param.E;
    F   = param.F;
    k   = param.k;
    CAf = param.CAf;

    r   = k*CA^2;
    RA  = -r;

    D   = E(l)/(1 - F(l))*(CA - CAf) - RA;
end