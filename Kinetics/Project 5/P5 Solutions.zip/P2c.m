function [] = P2c
    clear variables
    t           = linspace(0,2,1000)';
    C           = t;
    index       = t >= 1;
    C(index)    = -1*t(index)+2;
    Etemp       = C/trapz(t,C);  %Area on the C curve is 1 anyway, so it doesn't matter, but technically...
    Epp         = interp1(t,Etemp,'linear','pp');
    E           = @(t)(ppval(Epp,t)); %1/min
    
    k1          = 0.5; %L/mol/min
    k2          = 0.12; %L/mol/min
    CAf         = 1; %mol/L
    CBf         = 0;
    CCf         = 0;
    param.k     = [k1;k2];
    param.Cf    = [CAf;CBf;CCf];
    param.E     = E;
    
    f           = @(t,C)(P2c1(t,C,param));
    tspan       = [0,max(t)];
    C0          = [CAf,CBf,CCf,0,0,0];
    [tout,C]    = ode15s(f,tspan,C0);
    CAbar       = C(end,4);
    CBbar       = C(end,5);
    CCbar       = C(end,6);
    Cbar        = [CAbar, CBbar, CCbar];
    XA          = (CAf - CAbar)/CAf;
    SB          = 2*CBbar/(CAf - CAbar);
    SC          = 3*CCbar/(CAf - CAbar);
    
    fprintf(' CAbar = %4.2f\r CBbar = %4.2f\r CCbar = %4.2f\r XA = %4.4f\r SB = %4.2f\r SC = %4.2f\r', CAbar, CBbar, CCbar, XA, SB, SC)
end

function [D] = P2c1(t,C,param)
    CA      = C(1);
    CB      = C(2);
    CC      = C(3);

    E       = param.E;
    k1      = param.k(1);
    k2      = param.k(2);
    r1      = k1*CA^2;
    r2      = k2*CA*CB;
    RA      = -2*r1 - r2;
    RB      =    r1 - r2;
    RC      =    r2;

    D       = zeros(6,1);
    D(1)    = RA;
    D(2)    = RB;
    D(3)    = RC;
    D(4)    = CA*E(t);
    D(5)    = CB*E(t);
    D(6)    = CC*E(t);
end